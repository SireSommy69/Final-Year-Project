create database sms;
studencitytsemail